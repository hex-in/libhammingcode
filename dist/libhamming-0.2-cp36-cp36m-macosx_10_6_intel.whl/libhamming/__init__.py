# -*- coding:utf-8 -*-
""" Library for hamming code """
# !/usr/bin/python
# Python:   3.6.5
# Platform: Windows/Linux
# Author:   Heyn (heyunhuan@gmail.com)
# Program:  Library for hamming code.
# History:  2019-03-21 Wheel Ver:0.2 [Heyn] Initialize


from .hamming  import *
